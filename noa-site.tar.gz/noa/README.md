# NOA — Dubai's First Floating Beach Club

Static multi-page site. AZURA design system extended into 9 pages.

## Files

- `index.html` — homepage (hero, ticker, packages, restaurant, events, amenities, location, FAQ)
- `morning-package.html`, `afternoon-package.html`, `cabana.html` — package detail pages
- `events.html` — full event calendar (March–May 2026)
- `about.html` — origin story, vessel specs
- `location.html` — how to arrive, marina pier, shuttle info
- `faq.html` — full FAQ across 4 categories
- `contact.html` — contact form (department dropdown, message, consent)
- `style.css` — shared stylesheet (Josefin Sans + Cormorant, white/black minimalist)
- `script.js` — shared client behavior (cursor follower, sticky nav, reveal animations, FAQ accordion)

## Stack

Pure HTML/CSS/JS. No build step. No dependencies. Drop in any static host.

## Local preview

```bash
python3 -m http.server 8000
# open http://localhost:8000
```

## Deploy

Drop the entire folder onto Netlify, Vercel, Cloudflare Pages, or any static host. No build command needed.

## To-do before launch

- `contact.html` form submits to a placeholder JS alert. Hook to Formspree, Basin, or your backend.
- Phone `+971 4 840 0000` and email `hello@noa-dubai.com` are placeholders.
- Event lineup beyond the 3 March headliners is placeholder content — replace with real bookings.
- Press / Partnerships / Careers footer links all route to `contact.html` — split into dedicated pages later if needed.
